const brands = [
  { name: "Maruti Suzuki", logo: "🚗" },
  { name: "Hyundai", logo: "🚙" },
  { name: "Honda", logo: "🚕" },
  { name: "Tata", logo: "🚐" },
  { name: "Toyota", logo: "🚗" },
  { name: "Mahindra", logo: "🚙" },
  { name: "Kia", logo: "🚕" },
  { name: "Volkswagen", logo: "🚐" },
  { name: "Renault", logo: "🚗" },
  { name: "Ford", logo: "🚙" },
  { name: "Nissan", logo: "🚕" },
  { name: "Skoda", logo: "🚐" },
];

const CarBrands = () => {
  return (
    <section className="py-20 gradient-hero">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-primary-foreground mb-4">
            We Service All Major Brands
          </h2>
          <p className="text-xl text-primary-foreground/90 max-w-2xl mx-auto">
            Expert maintenance and repairs for every car manufacturer
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {brands.map((brand, index) => (
            <div
              key={index}
              className="glass-card p-6 rounded-xl card-hover flex flex-col items-center justify-center gap-3 min-h-[140px]"
            >
              <div className="text-5xl">{brand.logo}</div>
              <p className="text-sm font-semibold text-primary text-center">{brand.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CarBrands;
