import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Wrench, Wind, Paintbrush, Cog, Battery, Car } from "lucide-react";
import engineImage from "@/assets/engine-service.jpg";
import acImage from "@/assets/ac-service.jpg";
import paintImage from "@/assets/body-paint.jpg";

const services = [
  {
    icon: Wrench,
    title: "Engine Repair",
    description: "Complete engine diagnostics and repair services",
    price: "Starting from ₹1,200",
    image: engineImage,
  },
  {
    icon: Wind,
    title: "AC Service",
    description: "AC repair, gas refilling, and maintenance",
    price: "Starting from ₹2,500",
    image: acImage,
  },
  {
    icon: Paintbrush,
    title: "Body Painting",
    description: "Full body painting and denting services",
    price: "Starting from ₹15,000",
    image: paintImage,
  },
  {
    icon: Cog,
    title: "Clutch Replacement",
    description: "Clutch plate and pressure plate replacement",
    price: "Starting from ₹6,000",
  },
  {
    icon: Battery,
    title: "Electrical Work",
    description: "Complete electrical diagnostics and repair",
    price: "Starting from ₹800",
  },
  {
    icon: Car,
    title: "General Service",
    description: "Oil change, filters, and basic maintenance",
    price: "Starting from ₹1,500",
  },
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Our Services</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive auto care solutions for all your vehicle needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="card-hover group overflow-hidden border-2 hover:border-primary/50"
            >
              {service.image && (
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card/90 to-transparent" />
                </div>
              )}
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <service.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </div>
                <CardDescription className="text-base">{service.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-lg font-bold text-accent">{service.price}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
