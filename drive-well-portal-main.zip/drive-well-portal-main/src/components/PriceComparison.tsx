import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

const priceData = [
  {
    service: "Engine Oil Change",
    ourPrice: "₹1,200",
    competitors: "₹1,500–₹2,000",
    savings: "20-40%",
  },
  {
    service: "AC Repair",
    ourPrice: "₹2,500",
    competitors: "₹3,000–₹3,800",
    savings: "15-35%",
  },
  {
    service: "Full Body Painting",
    ourPrice: "₹15,000",
    competitors: "₹18,000–₹25,000",
    savings: "20-40%",
  },
  {
    service: "Clutch Replacement",
    ourPrice: "₹6,000",
    competitors: "₹7,500–₹9,000",
    savings: "20-33%",
  },
  {
    service: "Brake Pad Replacement",
    ourPrice: "₹2,800",
    competitors: "₹3,500–₹4,500",
    savings: "20-38%",
  },
  {
    service: "Battery Replacement",
    ourPrice: "₹4,500",
    competitors: "₹5,500–₹6,500",
    savings: "18-31%",
  },
];

const PriceComparison = () => {
  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Why Choose Us?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-6">
            Compare our competitive pricing with nearby workshops
          </p>
          <Badge className="bg-success text-success-foreground text-base px-4 py-2">
            <Check className="w-4 h-4 mr-2" />
            Best Price Guarantee
          </Badge>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="bg-card rounded-2xl shadow-xl overflow-hidden border-2 border-primary/20">
            <Table>
              <TableHeader>
                <TableRow className="bg-primary hover:bg-primary">
                  <TableHead className="text-primary-foreground font-bold text-base">Service</TableHead>
                  <TableHead className="text-primary-foreground font-bold text-base">Our Workshop</TableHead>
                  <TableHead className="text-primary-foreground font-bold text-base">Other Local Shops</TableHead>
                  <TableHead className="text-primary-foreground font-bold text-base text-right">You Save</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {priceData.map((row, index) => (
                  <TableRow key={index} className="hover:bg-muted/50">
                    <TableCell className="font-semibold">{row.service}</TableCell>
                    <TableCell className="font-bold text-accent text-lg">{row.ourPrice}</TableCell>
                    <TableCell className="text-muted-foreground">{row.competitors}</TableCell>
                    <TableCell className="text-right">
                      <Badge variant="outline" className="bg-success/10 text-success border-success/30 font-semibold">
                        {row.savings}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              * Prices may vary based on car model and specific requirements
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PriceComparison;
