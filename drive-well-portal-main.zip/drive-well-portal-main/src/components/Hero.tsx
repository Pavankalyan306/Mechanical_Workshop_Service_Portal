import { Button } from "@/components/ui/button";
import { Phone, Wrench } from "lucide-react";
import heroImage from "@/assets/hero-workshop.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImage} 
          alt="Professional automotive workshop" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/80 to-primary/70" />
      </div>

      {/* Content */}
      <div className="container relative z-10 mx-auto px-4 py-20">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 mb-6">
            <Wrench className="w-8 h-8 text-accent" />
            <span className="text-accent font-semibold text-lg">Premium Auto Care</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-primary-foreground mb-6 leading-tight">
            Trusted Auto Care in Chittoor
          </h1>
          
          <p className="text-xl md:text-2xl text-primary-foreground/90 mb-8 leading-relaxed">
            Expert mechanical services for all car brands. Quality repairs, competitive pricing, and customer satisfaction guaranteed.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="xl" 
              variant="cta"
              onClick={() => document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Book Service Now
            </Button>
            <Button 
              size="xl" 
              variant="hero"
              onClick={() => window.location.href = 'tel:+919618817597'}
            >
              <Phone className="w-5 h-5" />
              Call Now
            </Button>
          </div>

          {/* Trust Badges */}
          <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-primary-foreground/20">
            <div className="text-center">
              <div className="text-3xl font-bold text-accent mb-1">500+</div>
              <div className="text-sm text-primary-foreground/80">Happy Customers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-accent mb-1">15+</div>
              <div className="text-sm text-primary-foreground/80">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-accent mb-1">4.9★</div>
              <div className="text-sm text-primary-foreground/80">Customer Rating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
