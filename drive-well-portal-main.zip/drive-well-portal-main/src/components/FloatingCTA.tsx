import { Phone, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const FloatingCTA = () => {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3">
      <Button
        size="icon"
        variant="cta"
        className="h-14 w-14 rounded-full shadow-2xl animate-pulse hover:animate-none"
        onClick={() => window.location.href = 'tel:+919618817597'}
        title="Call Now"
      >
        <Phone className="w-6 h-6" />
      </Button>
      
      <Button
        size="icon"
        className="h-14 w-14 rounded-full shadow-2xl bg-success hover:bg-success/90"
        onClick={() => window.open('https://wa.me/919618817597', '_blank')}
        title="WhatsApp"
      >
        <MessageCircle className="w-6 h-6" />
      </Button>
    </div>
  );
};

export default FloatingCTA;
