import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

const reviews = [
  {
    name: "Rajesh Kumar",
    rating: 5,
    comment: "Excellent service! They fixed my car's engine issue quickly and professionally. Highly recommended!",
    date: "2 weeks ago",
  },
  {
    name: "Priya Sharma",
    rating: 5,
    comment: "Best workshop in Chittoor. Fair pricing and honest service. My Honda Civic runs like new after their maintenance.",
    date: "1 month ago",
  },
  {
    name: "Anil Reddy",
    rating: 5,
    comment: "Professional team with great expertise. They explained everything clearly before starting the work.",
    date: "3 weeks ago",
  },
  {
    name: "Meena Patel",
    rating: 4,
    comment: "Good service and reasonable prices. AC repair was done perfectly. Will definitely come back!",
    date: "1 week ago",
  },
  {
    name: "Suresh Babu",
    rating: 5,
    comment: "Trustworthy and skilled mechanics. They saved me a lot of money compared to other workshops.",
    date: "2 months ago",
  },
  {
    name: "Lakshmi Devi",
    rating: 5,
    comment: "Very satisfied with their body painting work. Looks brand new! Thank you for the excellent service.",
    date: "3 weeks ago",
  },
];

const Reviews = () => {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Customer Reviews
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers
          </p>
          <div className="flex items-center justify-center gap-2 mt-4">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="w-6 h-6 fill-accent text-accent" />
              ))}
            </div>
            <span className="text-lg font-semibold">4.9 out of 5 stars</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <Card key={index} className="card-hover">
              <CardContent className="p-6">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < review.rating
                          ? "fill-accent text-accent"
                          : "fill-muted text-muted"
                      }`}
                    />
                  ))}
                </div>
                <p className="text-foreground mb-4 leading-relaxed">
                  "{review.comment}"
                </p>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-foreground">{review.name}</p>
                    <p className="text-sm text-muted-foreground">{review.date}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
