import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import CarBrands from "@/components/CarBrands";
import PriceComparison from "@/components/PriceComparison";
import BookingForm from "@/components/BookingForm";
import Location from "@/components/Location";
import Reviews from "@/components/Reviews";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16 md:pt-20">
        <Hero />
        <Services />
        <CarBrands />
        <PriceComparison />
        <BookingForm />
        <Reviews />
        <Location />
      </main>
      <Footer />
      <FloatingCTA />
    </div>
  );
};

export default Index;
